const userModel = require('../models/userModel');
const jwt = require('jsonwebtoken');

const SECRET_KEY = 'your-secret-key'; // In a real app, use environment variables

exports.register = (req, res) => {
  const { username, password, email } = req.body;
  if (userModel.findByUsername(username)) {
    return res.status(400).json({ message: 'Username already exists' });
  }
  const user = userModel.create({ username, password, email });
  res.status(201).json({ message: 'User registered successfully', userId: user.id });
};

exports.login = (req, res) => {
  const { username, password } = req.body;
  const user = userModel.findByUsername(username);
  if (!user || user.password !== password) {
    return res.status(401).json({ message: 'Invalid credentials' });
  }
  const token = jwt.sign({ userId: user.id }, SECRET_KEY, { expiresIn: '1h' });
  res.json({ token });
};

exports.getProfile = (req, res) => {
  const user = userModel.findById(req.userId);
  if (!user) {
    return res.status(404).json({ message: 'User not found' });
  }
  res.json({ username: user.username, email: user.email });
};