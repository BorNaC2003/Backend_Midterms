let users = [];
let nextId = 1;

exports.create = (userData) => {
  const user = { id: nextId++, ...userData };
  users.push(user);
  return user;
};

exports.findByUsername = (username) => {
  return users.find(user => user.username === username);
};

exports.findById = (id) => {
  return users.find(user => user.id === id);
};